﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using GeografWPF.Class;
using GeografWPF.Classes;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;

namespace GeografWPF.Resusrs
{
    /// <summary>
    /// Логика взаимодействия для PageCountry.xaml
    /// </summary>
    public partial class PageCountry : System.Windows.Controls.Page
    {
        public PageCountry()
        {
            InitializeComponent();
            DtgSQL.ItemsSource = GeografyEntities1.GetContext().Country.ToList();
            CMBFilterCountry.ItemsSource = GeografyEntities1.GetContext().Country.ToList();
            CMBFilterCountry.SelectedValuePath = "Id_country";
            CMBFilterCountry.DisplayMemberPath = "Name";
        }

        private void BTNedit_Click(object sender, RoutedEventArgs e)
        {
            Class.ClassFrame.frmObj.Navigate(new Addcon((Country)DtgSQL.SelectedItem));
        }

        private void BTNadd_Click(object sender, RoutedEventArgs e)
        {
            Class.ClassFrame.frmObj.Navigate(new Addcon(null));
        }

        private void BTNdel_Click(object sender, RoutedEventArgs e)
        {
            var personsForRemoving = DtgSQL.SelectedItems.Cast<Country>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {personsForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    GeografyEntities1.GetContext().Country.RemoveRange(personsForRemoving);
                    GeografyEntities1.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgSQL.ItemsSource = GeografyEntities1.GetContext().Country.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }
        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                GeografyEntities1.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DtgSQL.ItemsSource = GeografyEntities1.GetContext().Country.ToList();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            CMBFilterCountry.SelectedItem = null;
            DtgSQL.ItemsSource = GeografyEntities1.GetContext().Country.ToList();
        }

        private void CMBFilterCountry_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int Id_country = Convert.ToInt32(CMBFilterCountry.SelectedValue);
            DtgSQL.ItemsSource = GeografyEntities1.GetContext().Country.Where(x => x.Id_country == Id_country).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DtgSQL.ItemsSource = GeografyEntities1.GetContext().Country.OrderBy(x => x.Name).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DtgSQL.ItemsSource = GeografyEntities1.GetContext().Country.OrderByDescending(x => x.Name).ToList();
        }

        private void FindCountry_TextChanged(object sender, TextChangedEventArgs e)
        {
            DtgSQL.ItemsSource = GeografyEntities1.GetContext().Country.Where(x => x.Name.ToLower().Contains(FindCountry.Text.ToLower())).ToList();
        }

        private void BtnToList_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new ListW());
        }

        private void btnExcel_Click(object sender, RoutedEventArgs e)
        {
            // получение списка данных
            var app = new Excel.Application();
            Excel.Workbook wb = app.Workbooks.Add();
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int indexRows = 1;
            worksheet.Cells[1][indexRows] = "Номер"; //номер столбца; номер строки 
            worksheet.Cells[2][indexRows] = "Страна";
            worksheet.Cells[3][indexRows] = "Столица";
            worksheet.Cells[4][indexRows] = "Площадь";
            var printItems = GeografyEntities1.GetContext().Country.ToList();
            foreach (var item in printItems)
            {
                worksheet.Cells[1][indexRows + 1] = indexRows;
                worksheet.Cells[2][indexRows + 1] = item.Name;
                worksheet.Cells[3][indexRows + 1] = item.Capital;
                worksheet.Cells[4][indexRows + 1] = item.Square;
                indexRows++;
            }
            app.Visible = true;
        }

        private void btnWord_Click(object sender, RoutedEventArgs e)
        {
            var allCountry = GeografyEntities1.GetContext().Country.ToList();
            var allRegions = GeografyEntities1.GetContext().Region.ToList();
            var app = new Word.Application();
            Word.Document document = app.Documents.Add();
            foreach (var counrty in allCountry)
            {
                Word.Paragraph counrtyParagraf = document.Paragraphs.Add();
                Word.Range counrtyRange = counrtyParagraf.Range;
                counrtyRange.Text = counrty.Name;
                counrtyParagraf.set_Style("Title");
                counrtyRange.InsertParagraphAfter();

                Word.Paragraph tableParagraph = document.Paragraphs.Add();
                Word.Range tableRange = tableParagraph.Range;
                Word.Table paymentsTable = document.Tables.Add(tableRange, allRegions.Count() + 1, 3);
                paymentsTable.Borders.InsideLineStyle = paymentsTable.Borders.OutsideLineStyle = Word.WdLineStyle.wdLineStyleSingle;
                paymentsTable.Range.Cells.VerticalAlignment = Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;
                Word.Range cellRange;
                cellRange = paymentsTable.Cell(1, 1).Range;
                cellRange.Text = "Страна";
                cellRange = paymentsTable.Cell(1, 2).Range;
                cellRange.Text = "Регион";
                paymentsTable.Rows[1].Range.Bold = 1;
                paymentsTable.Rows[1].Range.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;

                for (int i = 0; i < allRegions.Count; i++)
                {
                    var currentRegion = allRegions[i];
                    cellRange = paymentsTable.Cell(i + 2, 1).Range;
                    Word.InlineShape imageShape = cellRange.InlineShapes.AddPicture(AppDomain.CurrentDomain.BaseDirectory + "..\\..\\" + currentRegion.Region1);
                    imageShape.Width = imageShape.Height = 40;
                    cellRange.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                    cellRange = paymentsTable.Cell(i + 2, 2).Range;
                    cellRange.Text = currentRegion.Region1;
                }
            }
        }
    }
}
